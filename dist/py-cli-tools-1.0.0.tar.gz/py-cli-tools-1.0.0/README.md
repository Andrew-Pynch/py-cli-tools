# py-cli-tools

[![PyPI version](https://badge.fury.io/py/py-cli-tools.svg)](https://badge.fury.io/py/py-cli-tools)

Functions that I found myself writing in different projects over and over again go here
